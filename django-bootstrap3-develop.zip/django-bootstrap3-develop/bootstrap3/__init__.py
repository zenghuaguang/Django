# -*- coding: utf-8 -*-

__version__ = '7.1.0'
