=========
Changelog
=========


Changes in -master-
===================
* working sessions
* forms?
* added support for embedded fields


Changes in 0.1
===============

* Released to PyPi
