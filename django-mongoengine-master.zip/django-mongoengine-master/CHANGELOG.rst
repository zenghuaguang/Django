===========
2016-01-27
===========

* Support for django 1.9, minimum django version: 1.7
* Moved `django_mongoengine.mongo_auth.MongoUser` to `django_mongoengine.mongo_auth.models.MongoUser`
