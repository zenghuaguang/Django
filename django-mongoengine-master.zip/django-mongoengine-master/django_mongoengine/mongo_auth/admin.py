from django.contrib.auth.models import User, Group

from django_mongoengine import mongo_admin

#admin.site.unregister(Group)
#admin.site.unregister(User)
